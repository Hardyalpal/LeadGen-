/**
 * LeadGen AI - Frontend Application
 * Handles chat interface, API communication, and UI updates
 */

// ============================================
// Configuration
// ============================================
const API_BASE_URL = 'http://localhost:3000/api';

// ============================================
// DOM Elements
// ============================================
const chatMessages = document.getElementById('chat-messages');
const userInput = document.getElementById('user-input');
const sendBtn = document.getElementById('send-btn');
const loading = document.getElementById('loading');

// ============================================
// Event Listeners
// ============================================
document.addEventListener('DOMContentLoaded', () => {
    // Focus input on load
    userInput.focus();
});

// Send message on button click
sendBtn.addEventListener('click', sendMessage);

// Send message on Enter key
userInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendMessage();
    }
});

// Example click handlers
document.addEventListener('click', (e) => {
    if (e.target.tagName === 'LI' && e.target.parentElement.parentElement.classList.contains('examples')) {
        userInput.value = e.target.textContent.replace(/"/g, '');
        userInput.focus();
    }
});

// ============================================
// Core Functions
// ============================================

/**
 * Send user message to backend and handle response
 */
async function sendMessage() {
    const message = userInput.value.trim();
    
    if (!message) {
        return;
    }

    // Clear input
    userInput.value = '';

    // Add user message to chat
    addUserMessage(message);

    // Show loading
    showLoading(true);

    try {
        // Send request to backend
        const response = await fetch(`${API_BASE_URL}/chat`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ message })
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error || 'Failed to process request');
        }

        // Add bot response with results
        addBotResponse(data);

    } catch (error) {
        console.error('Error:', error);
        addErrorMessage(error.message);
    } finally {
        showLoading(false);
    }
}

/**
 * Add user message to chat
 */
function addUserMessage(message) {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message user-message';
    messageDiv.innerHTML = `
        <div class="message-avatar">👤</div>
        <div class="message-content">
            <p>${escapeHtml(message)}</p>
        </div>
    `;
    chatMessages.appendChild(messageDiv);
    scrollToBottom();
}

/**
 * Add bot response with results to chat
 */
function addBotResponse(data) {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message bot-message';
    
    let html = `
        <div class="message-avatar">🤖</div>
        <div class="message-content">
            <p>${escapeHtml(data.message)}</p>
    `;

    // Add query details if available
    if (data.query) {
        html += createQueryInfoHtml(data.query);
    }

    // Add results if available
    if (data.results && data.results.length > 0) {
        html += createResultsHtml(data.results, data.csvFile);
    }

    html += `</div>`;
    messageDiv.innerHTML = html;
    chatMessages.appendChild(messageDiv);
    scrollToBottom();
}

/**
 * Create HTML for query information
 */
function createQueryInfoHtml(query) {
    return `
        <div class="query-info">
            <h4>📋 Query Details</h4>
            <ul>
                <li><strong>Category:</strong> ${escapeHtml(query.category || 'N/A')}</li>
                <li><strong>Location:</strong> ${escapeHtml(query.location || 'N/A')}</li>
                <li><strong>Limit:</strong> ${query.limit || 'Default'}</li>
                ${query.filters ? `
                    <li><strong>Filters:</strong> ${formatFilters(query.filters)}</li>
                ` : ''}
            </ul>
        </div>
    `;
}

/**
 * Create HTML for results display
 */
function createResultsHtml(results, csvFile) {
    const previewData = results.slice(0, 5); // Show first 5 results
    
    let html = `
        <div class="results-container">
            <div class="results-header">
                <span>✅</span>
                <h3>Found ${results.length} Leads</h3>
            </div>
    `;

    // Add preview table
    if (previewData.length > 0) {
        html += createPreviewTable(previewData);
    }

    // Add download button
    if (csvFile) {
        html += `
            <a href="${API_BASE_URL}/download/${csvFile}" class="download-btn" download>
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                    <polyline points="7 10 12 15 17 10"></polyline>
                    <line x1="12" y1="15" x2="12" y2="3"></line>
                </svg>
                <span>Download CSV (${results.length} leads)</span>
            </a>
        `;
    }

    html += `</div>`;
    return html;
}

/**
 * Create preview table HTML
 */
function createPreviewTable(data) {
    const columns = Object.keys(data[0]).slice(0, 4); // Show first 4 columns
    
    let html = `
        <table class="preview-table">
            <thead>
                <tr>
                    ${columns.map(col => `<th>${escapeHtml(col)}</th>`).join('')}
                </tr>
            </thead>
            <tbody>
    `;

    data.forEach(row => {
        html += `<tr>`;
        columns.forEach(col => {
            let value = row[col];
            // Truncate long values
            if (typeof value === 'string' && value.length > 25) {
                value = value.substring(0, 25) + '...';
            }
            html += `<td>${escapeHtml(String(value))}</td>`;
        });
        html += `</tr>`;
    });

    html += `</tbody></table>`;
    
    if (data.length < 5) {
        html += `<p style="text-align: center; color: #64748b; font-size: 0.85rem; margin-top: 10px;">Showing all ${data.length} results</p>`;
    } else {
        html += `<p style="text-align: center; color: #64748b; font-size: 0.85rem; margin-top: 10px;">Showing first 5 results...</p>`;
    }
    
    return html;
}

/**
 * Add error message to chat
 */
function addErrorMessage(error) {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message bot-message';
    messageDiv.innerHTML = `
        <div class="message-avatar">⚠️</div>
        <div class="message-content">
            <div class="error-message">
                <strong>Error:</strong> ${escapeHtml(error)}
            </div>
            <p style="margin-top: 10px;">Please try again or check your query format.</p>
        </div>
    `;
    chatMessages.appendChild(messageDiv);
    scrollToBottom();
}

/**
 * Show/hide loading indicator
 */
function showLoading(show) {
    loading.classList.toggle('hidden', !show);
    sendBtn.disabled = show;
}

/**
 * Scroll chat to bottom
 */
function scrollToBottom() {
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

/**
 * Escape HTML to prevent XSS
 */
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

/**
 * Format filters for display
 */
function formatFilters(filters) {
    const filterList = [];
    if (filters.minRating) filterList.push(`Rating ≥ ${filters.minRating}`);
    if (filters.noWebsite) filterList.push('No Website');
    if (filters.hasWebsite) filterList.push('Has Website');
    return filterList.join(', ') || 'None';
}

// ============================================
// Utility Functions
// ============================================

/**
 * Check if server is running
 */
async function checkServerStatus() {
    try {
        const response = await fetch(`${API_BASE_URL}/health`);
        return response.ok;
    } catch (error) {
        return false;
    }
}

// Check server status on load
checkServerStatus().then(isRunning => {
    if (!isRunning) {
        addBotResponse({
            message: '⚠️ Warning: Backend server is not running. Please start the server with "npm start" in the backend directory.',
            query: null,
            results: null
        });
    }
});
