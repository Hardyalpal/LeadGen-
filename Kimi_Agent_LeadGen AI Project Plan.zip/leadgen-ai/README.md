# 🤖 LeadGen AI

> AI-powered lead generation system that converts natural language queries into structured business leads with CSV export.

[![Node.js](https://img.shields.io/badge/Node.js-14+-green.svg)](https://nodejs.org/)
[![Express](https://img.shields.io/badge/Express-4.x-blue.svg)](https://expressjs.com/)
[![License](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

---

## ✨ Features

- **📝 Natural Language Queries** - Just type what you need, e.g., "Find 50 dermatologists in Mumbai with good ratings"
- **🤖 AI-Powered Parsing** - Extracts structured data (category, location, filters, limit) from your queries
- **🔍 Smart Filtering** - Filter by rating, website availability, and more
- **📊 CSV Export** - Download leads as CSV files with one click
- **💬 Chat Interface** - Clean, intuitive chat UI for easy interaction
- **⚡ Fast & Scalable** - Modular architecture ready for real scraper integration

---

## 🏗️ Project Structure

```
leadgen-ai/
│
├── frontend/                 # Frontend files
│   ├── index.html           # Main HTML file
│   ├── style.css            # Stylesheet
│   └── app.js               # Frontend JavaScript
│
├── backend/                  # Backend files
│   ├── server.js            # Express server
│   │
│   ├── routes/              # API routes
│   │   └── chat.js          # Chat endpoint
│   │
│   ├── services/            # Business logic
│   │   ├── aiService.js     # AI query parsing
│   │   ├── scraperService.js # Lead fetching (mock)
│   │   ├── filterService.js # Lead filtering
│   │   └── csvService.js    # CSV generation
│   │
│   ├── config/              # Configuration
│   │   └── env.js           # Environment variables
│   │
│   └── utils/               # Utilities
│       └── helpers.js       # Helper functions
│
├── .env                      # Environment variables
├── package.json              # Dependencies
└── README.md                 # This file
```

---

## 🚀 Quick Start

### Prerequisites

- [Node.js](https://nodejs.org/) (v14 or higher)
- npm (comes with Node.js)
- OpenAI API key (optional - system works without it using mock parser)

### Installation

1. **Clone or extract the project:**
   ```bash
   cd leadgen-ai
   ```

2. **Install dependencies:**
   ```bash
   npm install
   ```

3. **Configure environment variables (optional):**
   ```bash
   # Edit .env file and add your OpenAI API key
   OPENAI_API_KEY=your_actual_api_key_here
   ```

4. **Start the server:**
   ```bash
   npm start
   ```

5. **Open the frontend:**
   - Open `frontend/index.html` in your browser
   - Or use a local server like Live Server in VS Code

---

## 📖 Usage Examples

### Example Queries

Try these queries in the chat interface:

```
"Find 50 dermatologists in Mumbai with good ratings"
```

```
"Get 30 restaurants in Delhi with rating above 4"
```

```
"Search for dentists in Bangalore without websites"
```

```
"Find 25 gyms in Pune with high ratings"
```

### Query Structure

The AI understands these components:

| Component | Example | Description |
|-----------|---------|-------------|
| **Category** | dermatologist, restaurant, dentist | Type of business |
| **Location** | Mumbai, Delhi, Bangalore | City or area |
| **Limit** | 50, 30, 100 | Number of leads to find |
| **Rating** | good ratings, above 4, 4.5 stars | Minimum rating filter |
| **Website** | no website, has website | Website availability filter |

---

## 🔌 API Endpoints

### Main Chat Endpoint

```http
POST /api/chat
Content-Type: application/json

{
  "message": "Find 50 dermatologists in Mumbai with good ratings"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Successfully found 45 leads matching your criteria!",
  "query": {
    "category": "dermatologist",
    "location": "mumbai",
    "limit": 50,
    "filters": {
      "minRating": 4,
      "noWebsite": false,
      "hasWebsite": false
    }
  },
  "results": [...],
  "csvFile": "leads_dermatologist_mumbai_2024-01-15T10-30-00_abc123.csv"
}
```

### Health Check

```http
GET /api/health
```

### Download CSV

```http
GET /api/download/{filename}
```

---

## ⚙️ Configuration

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `PORT` | 3000 | Server port |
| `OPENAI_API_KEY` | - | OpenAI API key for AI parsing |
| `SCRAPER_TIMEOUT` | 30000 | Scraper timeout in ms |
| `MAX_LEADS_PER_REQUEST` | 100 | Maximum leads per request |
| `CSV_CLEANUP_HOURS` | 24 | Auto-delete CSV files after hours |

### Without OpenAI API Key

The system works perfectly without an OpenAI API key! It uses a smart mock parser that extracts:

- Categories from keyword matching
- Locations from a predefined list
- Limits from number patterns
- Filters from common phrases

---

## 🛠️ Development

### Run in Development Mode

```bash
npm run dev
```

### Run Tests

```bash
npm test
```

### Lint Code

```bash
npm run lint
```

### Cleanup Old CSV Files

```bash
npm run cleanup
```

---

## 🔮 Future Enhancements

### Planned Features

- [ ] **Real Google Maps Scraper** - Integrate with Puppeteer or Google Places API
- [ ] **Database Integration** - Store leads in MongoDB/PostgreSQL
- [ ] **User Authentication** - Login/signup system
- [ ] **Lead History** - Save and view past searches
- [ ] **Advanced Filters** - Filter by phone, email, reviews count
- [ ] **Export Formats** - Excel, JSON, PDF export options
- [ ] **Email Integration** - Send leads via email
- [ ] **Rate Limiting** - API rate limiting for production
- [ ] **Caching** - Redis caching for faster responses
- [ ] **Webhook Support** - Send leads to external systems

### Scraper Integration Guide

To replace mock data with real scraping:

1. Install scraping library:
   ```bash
   npm install puppeteer
   ```

2. Update `scraperService.js`:
   ```javascript
   const puppeteer = require('puppeteer');
   
   async function scrapeGoogleMaps(category, location, limit) {
     const browser = await puppeteer.launch();
     // ... scraping logic
     return leads;
   }
   ```

---

## 🐛 Troubleshooting

### Common Issues

**Server won't start:**
```bash
# Check if port 3000 is in use
lsof -i :3000

# Kill process or change PORT in .env
```

**CORS errors:**
- Ensure backend is running on `http://localhost:3000`
- Check that CORS is enabled in `server.js`

**CSV download not working:**
- Check `downloads/` folder exists
- Verify file permissions

### Debug Mode

Enable debug logging:
```bash
ENABLE_DEBUG_LOGS=true npm start
```

---

## 📄 License

This project is licensed under the MIT License.

---

## 🙏 Acknowledgments

- [Express.js](https://expressjs.com/) - Web framework
- [OpenAI](https://openai.com/) - AI parsing (optional)
- [CORS](https://github.com/expressjs/cors) - Cross-origin handling

---

## 📞 Support

For issues or questions:

1. Check the [Troubleshooting](#troubleshooting) section
2. Review the code comments
3. Create an issue in the project repository

---

<p align="center">
  <strong>Built with ❤️ for lead generation</strong>
</p>
