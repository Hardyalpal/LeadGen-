/**
 * LeadGen AI - Main Server File
 * Express server with routes and middleware configuration
 */

const express = require('express');
const cors = require('cors');
const path = require('path');
const chatRoutes = require('./routes/chat');

// Initialize Express app
const app = express();
const PORT = process.env.PORT || 3000;

// ============================================
// Middleware
// ============================================

// Enable CORS for frontend communication
app.use(cors({
    origin: '*', // Allow all origins for development
    methods: ['GET', 'POST'],
    allowedHeaders: ['Content-Type']
}));

// Parse JSON request bodies
app.use(express.json());

// Parse URL-encoded request bodies
app.use(express.urlencoded({ extended: true }));

// ============================================
// Static Files
// ============================================

// Serve CSV downloads
app.use('/downloads', express.static(path.join(__dirname, '../downloads')));

// ============================================
// Routes
// ============================================

// Health check endpoint
app.get('/api/health', (req, res) => {
    res.json({
        status: 'ok',
        message: 'LeadGen AI server is running',
        timestamp: new Date().toISOString()
    });
});

// API routes
app.use('/api/chat', chatRoutes);

// CSV download endpoint
app.get('/api/download/:filename', (req, res) => {
    const filename = req.params.filename;
    const filePath = path.join(__dirname, '../downloads', filename);
    
    res.download(filePath, filename, (err) => {
        if (err) {
            console.error('Download error:', err);
            res.status(404).json({
                error: 'File not found',
                message: 'The requested CSV file could not be found'
            });
        }
    });
});

// ============================================
// Error Handling
// ============================================

// 404 handler
app.use((req, res) => {
    res.status(404).json({
        error: 'Not Found',
        message: 'The requested endpoint does not exist'
    });
});

// Global error handler
app.use((err, req, res, next) => {
    console.error('Server Error:', err);
    res.status(500).json({
        error: 'Internal Server Error',
        message: err.message || 'Something went wrong'
    });
});

// ============================================
// Start Server
// ============================================

app.listen(PORT, () => {
    console.log('='.repeat(50));
    console.log('🚀 LeadGen AI Server Started');
    console.log('='.repeat(50));
    console.log(`📡 Server running on http://localhost:${PORT}`);
    console.log(`🔍 Health check: http://localhost:${PORT}/api/health`);
    console.log(`💬 Chat API: http://localhost:${PORT}/api/chat`);
    console.log('='.repeat(50));
});

module.exports = app;
