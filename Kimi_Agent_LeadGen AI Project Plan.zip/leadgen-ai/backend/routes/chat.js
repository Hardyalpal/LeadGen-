/**
 * LeadGen AI - Chat Routes
 * Handles chat messages and lead generation workflow
 */

const express = require('express');
const router = express.Router();
const aiService = require('../services/aiService');
const scraperService = require('../services/scraperService');
const filterService = require('../services/filterService');
const csvService = require('../services/csvService');

/**
 * POST /api/chat
 * Main chat endpoint - processes user queries and returns leads
 */
router.post('/', async (req, res) => {
    try {
        const { message } = req.body;

        // Validate input
        if (!message || typeof message !== 'string') {
            return res.status(400).json({
                error: 'Invalid input',
                message: 'Please provide a valid query message'
            });
        }

        console.log('\n' + '='.repeat(50));
        console.log('📝 Received Query:', message);
        console.log('='.repeat(50));

        // Step 1: Parse query using AI
        console.log('\n🔍 Step 1: Parsing query with AI...');
        const parsedQuery = await aiService.parseQuery(message);
        console.log('✅ Parsed Query:', JSON.stringify(parsedQuery, null, 2));

        // Step 2: Fetch leads from scraper
        console.log('\n🔍 Step 2: Fetching leads from scraper...');
        const leads = await scraperService.fetchLeads(
            parsedQuery.category,
            parsedQuery.location,
            parsedQuery.limit
        );
        console.log(`✅ Fetched ${leads.length} leads`);

        // Step 3: Apply filters
        console.log('\n🔍 Step 3: Applying filters...');
        const filteredLeads = filterService.applyFilters(leads, parsedQuery.filters);
        console.log(`✅ Filtered to ${filteredLeads.length} leads`);

        // Step 4: Generate CSV if leads found
        let csvFile = null;
        if (filteredLeads.length > 0) {
            console.log('\n🔍 Step 4: Generating CSV file...');
            csvFile = await csvService.generateCSV(filteredLeads, parsedQuery);
            console.log('✅ CSV generated:', csvFile);
        }

        // Prepare response
        const response = {
            success: true,
            message: filteredLeads.length > 0
                ? `Successfully found ${filteredLeads.length} leads matching your criteria!`
                : 'No leads found matching your criteria. Try adjusting your filters.',
            query: parsedQuery,
            results: filteredLeads,
            csvFile: csvFile,
            timestamp: new Date().toISOString()
        };

        console.log('\n✅ Response sent successfully');
        console.log('='.repeat(50) + '\n');

        res.json(response);

    } catch (error) {
        console.error('\n❌ Error processing chat request:', error);
        
        res.status(500).json({
            error: 'Processing failed',
            message: error.message || 'Failed to process your request. Please try again.'
        });
    }
});

/**
 * GET /api/chat/test
 * Test endpoint to verify route is working
 */
router.get('/test', (req, res) => {
    res.json({
        status: 'ok',
        message: 'Chat route is working correctly'
    });
});

module.exports = router;
