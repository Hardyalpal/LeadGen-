/**
 * LeadGen AI - Environment Configuration
 * Loads and validates environment variables
 */

const fs = require('fs');
const path = require('path');

// ============================================
// Load .env file manually (without dotenv package)
// ============================================

function loadEnvFile() {
    const envPath = path.join(__dirname, '../../.env');
    
    if (fs.existsSync(envPath)) {
        const envContent = fs.readFileSync(envPath, 'utf8');
        const lines = envContent.split('\n');
        
        lines.forEach(line => {
            // Skip comments and empty lines
            line = line.trim();
            if (line.startsWith('#') || line === '') {
                return;
            }
            
            // Parse KEY=VALUE
            const equalIndex = line.indexOf('=');
            if (equalIndex > 0) {
                const key = line.substring(0, equalIndex).trim();
                let value = line.substring(equalIndex + 1).trim();
                
                // Remove quotes if present
                if ((value.startsWith('"') && value.endsWith('"')) ||
                    (value.startsWith("'") && value.endsWith("'"))) {
                    value = value.slice(1, -1);
                }
                
                // Set in process.env if not already set
                if (!process.env[key]) {
                    process.env[key] = value;
                }
            }
        });
        
        console.log('✅ Environment variables loaded from .env file');
    } else {
        console.log('⚠️  .env file not found, using default values');
    }
}

// Load environment variables
loadEnvFile();

// ============================================
// Configuration Object
// ============================================

const config = {
    // Server Configuration
    PORT: parseInt(process.env.PORT, 10) || 3000,
    NODE_ENV: process.env.NODE_ENV || 'development',
    
    // OpenAI Configuration
    OPENAI_API_KEY: process.env.OPENAI_API_KEY || '',
    
    // Scraping Configuration
    SCRAPER_TIMEOUT: parseInt(process.env.SCRAPER_TIMEOUT, 10) || 30000,
    MAX_LEADS_PER_REQUEST: parseInt(process.env.MAX_LEADS_PER_REQUEST, 10) || 100,
    
    // CSV Configuration
    CSV_DOWNLOAD_PATH: process.env.CSV_DOWNLOAD_PATH || './downloads',
    CSV_CLEANUP_HOURS: parseInt(process.env.CSV_CLEANUP_HOURS, 10) || 24,
    
    // Rate Limiting
    RATE_LIMIT_WINDOW: parseInt(process.env.RATE_LIMIT_WINDOW, 10) || 60000, // 1 minute
    RATE_LIMIT_MAX: parseInt(process.env.RATE_LIMIT_MAX, 10) || 10, // 10 requests per window
    
    // Logging
    LOG_LEVEL: process.env.LOG_LEVEL || 'info',
    ENABLE_DEBUG_LOGS: process.env.ENABLE_DEBUG_LOGS === 'true'
};

// ============================================
// Validation Functions
// ============================================

/**
 * Check if OpenAI API key is configured
 * @returns {boolean}
 */
function isOpenAIConfigured() {
    return config.OPENAI_API_KEY && 
           config.OPENAI_API_KEY !== 'your_openai_api_key_here' &&
           config.OPENAI_API_KEY.startsWith('sk-');
}

/**
 * Get configuration summary (for debugging)
 * @returns {Object}
 */
function getConfigSummary() {
    return {
        port: config.PORT,
        environment: config.NODE_ENV,
        openaiConfigured: isOpenAIConfigured(),
        maxLeads: config.MAX_LEADS_PER_REQUEST,
        scraperTimeout: config.SCRAPER_TIMEOUT,
        csvCleanupHours: config.CSV_CLEANUP_HOURS
    };
}

/**
 * Validate required configuration
 * @throws {Error} If required config is missing
 */
function validateConfig() {
    const errors = [];
    
    if (config.PORT < 1 || config.PORT > 65535) {
        errors.push('Invalid PORT number');
    }
    
    if (config.MAX_LEADS_PER_REQUEST < 1 || config.MAX_LEADS_PER_REQUEST > 1000) {
        errors.push('MAX_LEADS_PER_REQUEST must be between 1 and 1000');
    }
    
    if (errors.length > 0) {
        throw new Error(`Configuration errors:\n${errors.join('\n')}`);
    }
    
    return true;
}

// ============================================
// Export
// ============================================

module.exports = {
    ...config,
    isOpenAIConfigured,
    getConfigSummary,
    validateConfig
};
