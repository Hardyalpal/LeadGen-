/**
 * LeadGen AI - Scraper Service
 * Fetches business leads data (currently mock data, ready for real scraper integration)
 */

const { delay, generateId } = require('../utils/helpers');

// ============================================
// Scraper Service Module
// ============================================

/**
 * Fetch leads based on search criteria
 * @param {string} category - Business category
 * @param {string} location - Location/city
 * @param {number} limit - Maximum number of leads
 * @returns {Promise<Array>} - Array of lead objects
 */
async function fetchLeads(category, location, limit = 50) {
    console.log(`🌐 Fetching leads: ${category} in ${location} (limit: ${limit})`);
    
    // Simulate network delay
    await delay(1000);
    
    // Generate mock leads data
    const leads = generateMockLeads(category, location, limit);
    
    console.log(`✅ Successfully generated ${leads.length} mock leads`);
    
    return leads;
}

/**
 * Generate realistic mock lead data
 * @param {string} category - Business category
 * @param {string} location - Location/city
 * @param {number} count - Number of leads to generate
 * @returns {Array} - Array of mock lead objects
 */
function generateMockLeads(category, location, count) {
    const leads = [];
    
    // Business name templates
    const namePrefixes = ['Dr.', 'New', 'City', 'Metro', 'Advanced', 'Modern', 'Prime', 'Elite', 'Royal', 'Smart'];
    const nameSuffixes = ['Center', 'Clinic', 'Hub', 'Point', 'Care', 'Plus', 'Pro', 'World', 'Zone', 'Hub'];
    
    // Street names
    const streets = [
        'MG Road', 'Linking Road', 'Park Street', 'Commercial Street', 
        'Brigade Road', 'FC Road', 'Bandra West', 'Andheri East',
        'Koramangala', 'Indiranagar', 'Hitech City', 'Salt Lake',
        'Janpath', 'Connaught Place', 'Marine Lines', 'Borivali'
    ];
    
    // Phone prefixes by location
    const phonePrefixes = {
        'mumbai': ['022', '7208', '7738', '9769', '8452'],
        'delhi': ['011', '7210', '9871', '8527', '9312'],
        'bangalore': ['080', '7892', '9631', '8547', '7206'],
        'hyderabad': ['040', '7893', '8524', '9632', '7410'],
        'chennai': ['044', '7894', '8526', '9633', '7412'],
        'kolkata': ['033', '7895', '8528', '9634', '7415'],
        'pune': ['020', '7896', '8529', '9635', '7418']
    };
    
    const defaultPrefixes = ['022', '7208', '9876', '8527', '7410'];
    const prefixes = phonePrefixes[location.toLowerCase()] || defaultPrefixes;
    
    for (let i = 0; i < count; i++) {
        const hasWebsite = Math.random() > 0.4; // 60% have websites
        const rating = generateRandomRating();
        const reviewCount = Math.floor(Math.random() * 500) + 5;
        
        const lead = {
            id: generateId(),
            name: generateBusinessName(category, location, namePrefixes, nameSuffixes, i),
            category: category.charAt(0).toUpperCase() + category.slice(1),
            address: generateAddress(location, streets),
            phone: generatePhoneNumber(prefixes),
            email: generateEmail(category, i),
            website: hasWebsite ? generateWebsite(category, i) : '',
            rating: rating,
            reviewCount: reviewCount,
            hasWebsite: hasWebsite,
            location: location.charAt(0).toUpperCase() + location.slice(1),
            source: 'Google Maps',
            scrapedAt: new Date().toISOString()
        };
        
        leads.push(lead);
    }
    
    return leads;
}

// ============================================
// Helper Functions
// ============================================

/**
 * Generate a random business name
 */
function generateBusinessName(category, location, prefixes, suffixes, index) {
    const prefix = prefixes[Math.floor(Math.random() * prefixes.length)];
    const suffix = suffixes[Math.floor(Math.random() * suffixes.length)];
    
    const nameFormats = [
        `${prefix} ${capitalize(category)} ${suffix}`,
        `${capitalize(location)} ${capitalize(category)} ${suffix}`,
        `${prefix} ${capitalize(category)} Care`,
        `${capitalize(category)} ${suffix} of ${capitalize(location)}`,
        `${prefix} Care ${capitalize(category)}`,
        `${capitalize(category)} Point ${index + 1}`,
        `${capitalize(location)} ${capitalize(category)} Hub`
    ];
    
    return nameFormats[index % nameFormats.length];
}

/**
 * Generate a random address
 */
function generateAddress(location, streets) {
    const street = streets[Math.floor(Math.random() * streets.length)];
    const buildingNum = Math.floor(Math.random() * 200) + 1;
    const area = generateAreaName(location);
    const pincode = generatePincode(location);
    
    return `${buildingNum}, ${street}, ${area}, ${capitalize(location)} - ${pincode}`;
}

/**
 * Generate area name based on location
 */
function generateAreaName(location) {
    const areas = {
        'mumbai': ['Andheri', 'Bandra', 'Juhu', 'Dadar', 'Powai', 'Malad'],
        'delhi': ['Karol Bagh', 'Lajpat Nagar', 'Connaught Place', 'Rajouri Garden', 'Dwarka'],
        'bangalore': ['Koramangala', 'Indiranagar', 'Whitefield', 'Jayanagar', 'HSR Layout'],
        'hyderabad': ['Banjara Hills', 'Jubilee Hills', 'Gachibowli', 'Hitech City', 'Madhapur'],
        'chennai': ['T Nagar', 'Adyar', 'Anna Nagar', 'Velachery', 'Mylapore'],
        'kolkata': ['Salt Lake', 'Park Street', 'Ballygunge', 'Alipore', 'New Town'],
        'pune': ['Koregaon Park', 'Kalyani Nagar', 'Aundh', 'Baner', 'Hinjewadi']
    };
    
    const locationAreas = areas[location.toLowerCase()] || ['Central', 'Main', 'City Center'];
    return locationAreas[Math.floor(Math.random() * locationAreas.length)];
}

/**
 * Generate pincode based on location
 */
function generatePincode(location) {
    const pincodes = {
        'mumbai': ['400001', '400050', '400053', '400028', '400076'],
        'delhi': ['110001', '110005', '110024', '110027', '110075'],
        'bangalore': ['560001', '560034', '560038', '560102', '560103'],
        'hyderabad': ['500001', '500034', '500081', '500084', '500032'],
        'chennai': ['600001', '600020', '600040', '600042', '600004'],
        'kolkata': ['700001', '700016', '700019', '700071', '700102'],
        'pune': ['411001', '411006', '411014', '411036', '411057']
    };
    
    const locationPincodes = pincodes[location.toLowerCase()] || ['400001', '110001', '560001'];
    return locationPincodes[Math.floor(Math.random() * locationPincodes.length)];
}

/**
 * Generate a random phone number
 */
function generatePhoneNumber(prefixes) {
    const prefix = prefixes[Math.floor(Math.random() * prefixes.length)];
    const suffix = Math.floor(Math.random() * 10000000).toString().padStart(7, '0');
    return `+91 ${prefix} ${suffix.slice(0, 4)} ${suffix.slice(4)}`;
}

/**
 * Generate a business email
 */
function generateEmail(category, index) {
    const domains = ['gmail.com', 'yahoo.com', 'outlook.com', 'business.in', 'pro.com'];
    const domain = domains[Math.floor(Math.random() * domains.length)];
    const cleanCategory = category.toLowerCase().replace(/\s+/g, '');
    return `contact.${cleanCategory}${index + 1}@${domain}`;
}

/**
 * Generate a website URL
 */
function generateWebsite(category, index) {
    const tlds = ['.com', '.in', '.co.in', '.net', '.org'];
    const tld = tlds[Math.floor(Math.random() * tlds.length)];
    const cleanCategory = category.toLowerCase().replace(/\s+/g, '');
    return `https://www.${cleanCategory}${index + 1}${tld}`;
}

/**
 * Generate a random rating (weighted towards higher ratings)
 */
function generateRandomRating() {
    const ratings = [3.0, 3.2, 3.5, 3.8, 4.0, 4.1, 4.2, 4.3, 4.4, 4.5, 4.6, 4.7, 4.8, 4.9, 5.0];
    const weights = [1, 2, 3, 4, 8, 10, 12, 14, 15, 14, 12, 10, 8, 5, 3]; // Higher weights for better ratings
    
    const totalWeight = weights.reduce((a, b) => a + b, 0);
    let random = Math.random() * totalWeight;
    
    for (let i = 0; i < ratings.length; i++) {
        random -= weights[i];
        if (random <= 0) {
            return ratings[i];
        }
    }
    
    return 4.0;
}

/**
 * Capitalize first letter
 */
function capitalize(str) {
    return str.charAt(0).toUpperCase() + str.slice(1);
}

// ============================================
// Future Integration: Real Google Maps Scraper
// ============================================

/**
 * TODO: Implement real Google Maps scraping
 * This function will be used when integrating with actual scraping library
 */
async function scrapeGoogleMaps(category, location, limit) {
    // Placeholder for future implementation
    // Could use libraries like:
    // - puppeteer (headless browser)
    // - google-maps-scraper (npm package)
    // - Google Places API
    
    throw new Error('Real scraper not implemented yet. Using mock data.');
}

// ============================================
// Export
// ============================================

module.exports = {
    fetchLeads,
    scrapeGoogleMaps // exported for future use
};
