/**
 * LeadGen AI - AI Service
 * Handles query parsing using OpenAI API or fallback mock parser
 */

const { OPENAI_API_KEY } = require('../config/env');

// ============================================
// AI Service Module
// ============================================

/**
 * Parse natural language query into structured data
 * @param {string} query - User's natural language query
 * @returns {Promise<Object>} - Structured query data
 */
async function parseQuery(query) {
    try {
        // Try OpenAI API if key is available
        if (OPENAI_API_KEY && OPENAI_API_KEY !== 'your_openai_api_key_here') {
            return await parseWithOpenAI(query);
        }
        
        // Fallback to mock parser
        console.log('⚠️  No OpenAI API key found, using mock parser');
        return parseWithMock(query);
        
    } catch (error) {
        console.error('AI parsing error:', error);
        // Fallback to mock parser on error
        return parseWithMock(query);
    }
}

/**
 * Parse query using OpenAI API
 * @param {string} query - User's natural language query
 * @returns {Promise<Object>} - Structured query data
 */
async function parseWithOpenAI(query) {
    const openai = require('openai');
    const client = new openai.OpenAI({ apiKey: OPENAI_API_KEY });

    const systemPrompt = `You are a query parser for a lead generation system. 
Extract the following information from the user's query and return ONLY a JSON object:

{
    "category": "business category (e.g., dermatologist, restaurant, dentist)",
    "location": "city or location (e.g., Mumbai, Delhi, Bangalore)",
    "limit": number (default 50 if not specified, max 100),
    "filters": {
        "minRating": number or null (e.g., 4 for "rating above 4"),
        "noWebsite": boolean (true if user wants businesses WITHOUT websites),
        "hasWebsite": boolean (true if user wants businesses WITH websites)
    }
}

Rules:
- Extract category from business type mentioned
- Extract location from city/area mentioned
- Default limit is 50 if not specified
- For ratings: "good ratings" = 4, "best" = 4.5, specific numbers as given
- Set noWebsite to true if query mentions "no website" or "without website"
- Return ONLY the JSON object, no markdown, no explanation`;

    const response = await client.chat.completions.create({
        model: 'gpt-3.5-turbo',
        messages: [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: query }
        ],
        temperature: 0.3,
        max_tokens: 200
    });

    const content = response.choices[0].message.content.trim();
    
    // Parse JSON response
    try {
        const parsed = JSON.parse(content);
        return validateAndNormalize(parsed);
    } catch (e) {
        console.error('Failed to parse OpenAI response:', content);
        return parseWithMock(query);
    }
}

/**
 * Parse query using mock parser (fallback)
 * @param {string} query - User's natural language query
 * @returns {Object} - Structured query data
 */
function parseWithMock(query) {
    const lowerQuery = query.toLowerCase();
    
    // Extract category
    const category = extractCategory(lowerQuery);
    
    // Extract location
    const location = extractLocation(lowerQuery);
    
    // Extract limit
    const limit = extractLimit(lowerQuery);
    
    // Extract filters
    const filters = extractFilters(lowerQuery);

    return {
        category,
        location,
        limit,
        filters
    };
}

// ============================================
// Helper Functions
// ============================================

/**
 * Extract business category from query
 */
function extractCategory(query) {
    const categories = {
        'dermatologist': 'dermatologist',
        'dermatologists': 'dermatologist',
        'doctor': 'doctor',
        'doctors': 'doctor',
        'dentist': 'dentist',
        'dentists': 'dentist',
        'restaurant': 'restaurant',
        'restaurants': 'restaurant',
        'hotel': 'hotel',
        'hotels': 'hotel',
        'cafe': 'cafe',
        'cafes': 'cafe',
        'gym': 'gym',
        'gyms': 'gym',
        'salon': 'salon',
        'salons': 'salon',
        'spa': 'spa',
        'spas': 'spa',
        'clinic': 'clinic',
        'clinics': 'clinic',
        'hospital': 'hospital',
        'hospitals': 'hospital',
        'pharmacy': 'pharmacy',
        'pharmacies': 'pharmacy',
        'school': 'school',
        'schools': 'school',
        'college': 'college',
        'colleges': 'college',
        'lawyer': 'lawyer',
        'lawyers': 'lawyer',
        'accountant': 'accountant',
        'accountants': 'accountant',
        'plumber': 'plumber',
        'plumbers': 'plumber',
        'electrician': 'electrician',
        'electricians': 'electrician',
        'mechanic': 'mechanic',
        'mechanics': 'mechanic'
    };

    for (const [key, value] of Object.entries(categories)) {
        if (query.includes(key)) {
            return value;
        }
    }

    return 'business'; // default
}

/**
 * Extract location from query
 */
function extractLocation(query) {
    const locations = [
        'mumbai', 'delhi', 'bangalore', 'bengaluru', 'hyderabad', 'chennai',
        'kolkata', 'pune', 'ahmedabad', 'jaipur', 'surat', 'lucknow',
        'kanpur', 'nagpur', 'indore', 'thane', 'bhopal', 'visakhapatnam',
        'pimpri', 'patna', 'vadodara', 'ghaziabad', 'ludhiana', 'agra',
        'nashik', 'faridabad', 'meerut', 'rajkot', 'kalyan', 'vasai',
        'varanasi', 'srinagar', 'aurangabad', 'dhanbad', 'amritsar',
        'navi mumbai', 'allahabad', 'ranchi', 'howrah', 'coimbatore',
        'jabalpur', 'gwalior', 'vijayawada', 'jodhpur', 'madurai',
        'raipur', 'kota', 'guwahati', 'chandigarh', 'solapur',
        'hubli', 'tiruchirappalli', 'tiruppur', 'moradabad', 'mysore',
        'bareilly', 'gurgaon', 'noida', 'new delhi'
    ];

    for (const location of locations) {
        if (query.includes(location)) {
            // Normalize bangalore
            if (location === 'bengaluru') return 'bangalore';
            return location;
        }
    }

    return 'india'; // default
}

/**
 * Extract limit from query
 */
function extractLimit(query) {
    // Look for patterns like "50", "100", "top 30", etc.
    const patterns = [
        /\b(\d+)\s*(?:leads?|results?|businesses?)/i,
        /\btop\s+(\d+)\b/i,
        /\bfind\s+(\d+)\b/i,
        /\bget\s+(\d+)\b/i,
        /\bsearch\s+(\d+)\b/i
    ];

    for (const pattern of patterns) {
        const match = query.match(pattern);
        if (match) {
            const limit = parseInt(match[1], 10);
            return Math.min(limit, 100); // Cap at 100
        }
    }

    return 50; // default
}

/**
 * Extract filters from query
 */
function extractFilters(query) {
    const filters = {
        minRating: null,
        noWebsite: false,
        hasWebsite: false
    };

    // Rating filters
    if (query.includes('rating above 4.5') || query.includes('4.5 star')) {
        filters.minRating = 4.5;
    } else if (query.includes('rating above 4') || query.includes('4 star') || 
               query.includes('good rating') || query.includes('high rating')) {
        filters.minRating = 4;
    } else if (query.includes('rating above 3') || query.includes('3 star')) {
        filters.minRating = 3;
    }

    // Website filters
    if (query.includes('no website') || query.includes('without website') || 
        query.includes('dont have website') || query.includes('no web')) {
        filters.noWebsite = true;
    } else if (query.includes('have website') || query.includes('with website') ||
               query.includes('has website')) {
        filters.hasWebsite = true;
    }

    return filters;
}

/**
 * Validate and normalize parsed query
 */
function validateAndNormalize(parsed) {
    return {
        category: parsed.category || 'business',
        location: parsed.location || 'india',
        limit: Math.min(Math.max(parseInt(parsed.limit) || 50, 1), 100),
        filters: {
            minRating: parsed.filters?.minRating || null,
            noWebsite: parsed.filters?.noWebsite || false,
            hasWebsite: parsed.filters?.hasWebsite || false
        }
    };
}

// ============================================
// Export
// ============================================

module.exports = {
    parseQuery
};
