/**
 * LeadGen AI - CSV Service
 * Generates CSV files from lead data
 */

const fs = require('fs');
const path = require('path');
const { generateId } = require('../utils/helpers');

// ============================================
// CSV Service Module
// ============================================

// Ensure downloads directory exists
const DOWNLOADS_DIR = path.join(__dirname, '../../downloads');

/**
 * Initialize downloads directory
 */
function initDownloadsDir() {
    if (!fs.existsSync(DOWNLOADS_DIR)) {
        fs.mkdirSync(DOWNLOADS_DIR, { recursive: true });
        console.log('📁 Created downloads directory:', DOWNLOADS_DIR);
    }
}

// Initialize on module load
initDownloadsDir();

/**
 * Generate CSV file from leads data
 * @param {Array} leads - Array of lead objects
 * @param {Object} query - Original query for filename
 * @returns {Promise<string>} - Filename of generated CSV
 */
async function generateCSV(leads, query = {}) {
    if (!leads || leads.length === 0) {
        throw new Error('No leads provided for CSV generation');
    }

    console.log(`📊 Generating CSV for ${leads.length} leads...`);

    // Generate CSV content
    const csvContent = convertToCSV(leads);

    // Generate filename
    const filename = generateFilename(query);
    const filepath = path.join(DOWNLOADS_DIR, filename);

    // Write to file
    fs.writeFileSync(filepath, csvContent, 'utf8');

    console.log(`✅ CSV file saved: ${filepath}`);
    console.log(`📄 File size: ${(fs.statSync(filepath).size / 1024).toFixed(2)} KB`);

    return filename;
}

/**
 * Convert leads array to CSV string
 * @param {Array} leads - Array of lead objects
 * @returns {string} - CSV formatted string
 */
function convertToCSV(leads) {
    if (!leads || leads.length === 0) {
        return '';
    }

    // Define column order (prioritize important fields)
    const priorityColumns = [
        'name',
        'category',
        'phone',
        'email',
        'website',
        'address',
        'location',
        'rating',
        'reviewCount',
        'hasWebsite',
        'source',
        'scrapedAt',
        'id'
    ];

    // Get all unique columns from all leads
    const allColumns = new Set();
    leads.forEach(lead => {
        Object.keys(lead).forEach(key => allColumns.add(key));
    });

    // Merge priority columns with any additional columns
    const columns = [
        ...priorityColumns.filter(col => allColumns.has(col)),
        ...[...allColumns].filter(col => !priorityColumns.includes(col))
    ];

    // Create CSV rows
    const rows = [];

    // Add header row
    rows.push(columns.join(','));

    // Add data rows
    leads.forEach(lead => {
        const row = columns.map(column => {
            const value = lead[column];
            return formatCSVValue(value);
        });
        rows.push(row.join(','));
    });

    return rows.join('\n');
}

/**
 * Format a value for CSV (handle special characters)
 * @param {*} value - Value to format
 * @returns {string} - Formatted CSV value
 */
function formatCSVValue(value) {
    // Handle null/undefined
    if (value === null || value === undefined) {
        return '';
    }

    // Convert to string
    let stringValue = String(value);

    // Check if value needs quoting
    const needsQuoting = 
        stringValue.includes(',') ||
        stringValue.includes('"') ||
        stringValue.includes('\n') ||
        stringValue.includes('\r');

    if (needsQuoting) {
        // Escape double quotes by doubling them
        stringValue = stringValue.replace(/"/g, '""');
        // Wrap in double quotes
        stringValue = `"${stringValue}"`;
    }

    return stringValue;
}

/**
 * Generate filename for CSV
 * @param {Object} query - Query object
 * @returns {string} - Generated filename
 */
function generateFilename(query = {}) {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const category = (query.category || 'leads').toLowerCase().replace(/\s+/g, '_');
    const location = (query.location || 'all').toLowerCase().replace(/\s+/g, '_');
    const uniqueId = generateId().slice(0, 8);

    return `leads_${category}_${location}_${timestamp}_${uniqueId}.csv`;
}

/**
 * Read CSV file content
 * @param {string} filename - Name of the file
 * @returns {string} - File content
 */
function readCSVFile(filename) {
    const filepath = path.join(DOWNLOADS_DIR, filename);
    
    if (!fs.existsSync(filepath)) {
        throw new Error(`File not found: ${filename}`);
    }

    return fs.readFileSync(filepath, 'utf8');
}

/**
 * Delete CSV file
 * @param {string} filename - Name of the file to delete
 * @returns {boolean} - Success status
 */
function deleteCSVFile(filename) {
    const filepath = path.join(DOWNLOADS_DIR, filename);
    
    if (fs.existsSync(filepath)) {
        fs.unlinkSync(filepath);
        console.log(`🗑️  Deleted file: ${filename}`);
        return true;
    }
    
    return false;
}

/**
 * List all generated CSV files
 * @returns {Array} - Array of file info objects
 */
function listCSVFiles() {
    initDownloadsDir();
    
    const files = fs.readdirSync(DOWNLOADS_DIR);
    
    return files
        .filter(file => file.endsWith('.csv'))
        .map(file => {
            const filepath = path.join(DOWNLOADS_DIR, file);
            const stats = fs.statSync(filepath);
            
            return {
                filename: file,
                size: stats.size,
                sizeFormatted: `${(stats.size / 1024).toFixed(2)} KB`,
                createdAt: stats.birthtime,
                modifiedAt: stats.mtime
            };
        })
        .sort((a, b) => b.createdAt - a.createdAt);
}

/**
 * Clean up old CSV files
 * @param {number} maxAgeHours - Maximum age in hours (default: 24)
 * @returns {number} - Number of files deleted
 */
function cleanupOldFiles(maxAgeHours = 24) {
    const files = listCSVFiles();
    const now = new Date();
    const maxAgeMs = maxAgeHours * 60 * 60 * 1000;
    let deletedCount = 0;

    files.forEach(file => {
        const age = now - new Date(file.createdAt);
        if (age > maxAgeMs) {
            deleteCSVFile(file.filename);
            deletedCount++;
        }
    });

    console.log(`🧹 Cleaned up ${deletedCount} old CSV files`);
    return deletedCount;
}

/**
 * Parse CSV string back to array (for verification)
 * @param {string} csvContent - CSV string
 * @returns {Array} - Array of objects
 */
function parseCSV(csvContent) {
    const lines = csvContent.split('\n').filter(line => line.trim() !== '');
    
    if (lines.length === 0) {
        return [];
    }

    // Parse header
    const headers = parseCSVLine(lines[0]);

    // Parse data rows
    const results = [];
    for (let i = 1; i < lines.length; i++) {
        const values = parseCSVLine(lines[i]);
        const row = {};
        
        headers.forEach((header, index) => {
            row[header] = values[index] || '';
        });

        results.push(row);
    }

    return results;
}

/**
 * Parse a single CSV line
 * @param {string} line - CSV line
 * @returns {Array} - Array of values
 */
function parseCSVLine(line) {
    const values = [];
    let current = '';
    let inQuotes = false;

    for (let i = 0; i < line.length; i++) {
        const char = line[i];
        const nextChar = line[i + 1];

        if (char === '"') {
            if (inQuotes && nextChar === '"') {
                // Escaped quote
                current += '"';
                i++; // Skip next quote
            } else {
                // Toggle quote state
                inQuotes = !inQuotes;
            }
        } else if (char === ',' && !inQuotes) {
            // End of field
            values.push(current.trim());
            current = '';
        } else {
            current += char;
        }
    }

    // Add last value
    values.push(current.trim());

    return values;
}

/**
 * Get CSV file info
 * @param {string} filename - Name of the file
 * @returns {Object} - File info
 */
function getFileInfo(filename) {
    const filepath = path.join(DOWNLOADS_DIR, filename);
    
    if (!fs.existsSync(filepath)) {
        return null;
    }

    const stats = fs.statSync(filepath);
    const content = fs.readFileSync(filepath, 'utf8');
    const lines = content.split('\n').filter(line => line.trim() !== '');

    return {
        filename,
        size: stats.size,
        sizeFormatted: `${(stats.size / 1024).toFixed(2)} KB`,
        createdAt: stats.birthtime,
        modifiedAt: stats.mtime,
        rowCount: Math.max(0, lines.length - 1), // Exclude header
        columnCount: lines.length > 0 ? lines[0].split(',').length : 0
    };
}

// ============================================
// Export
// ============================================

module.exports = {
    generateCSV,
    convertToCSV,
    readCSVFile,
    deleteCSVFile,
    listCSVFiles,
    cleanupOldFiles,
    parseCSV,
    getFileInfo,
    formatCSVValue,
    generateFilename
};
