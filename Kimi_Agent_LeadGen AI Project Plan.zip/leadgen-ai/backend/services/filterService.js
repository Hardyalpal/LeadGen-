/**
 * LeadGen AI - Filter Service
 * Applies filters to lead data based on user criteria
 */

// ============================================
// Filter Service Module
// ============================================

/**
 * Apply filters to leads array
 * @param {Array} leads - Array of lead objects
 * @param {Object} filters - Filter criteria
 * @returns {Array} - Filtered leads
 */
function applyFilters(leads, filters = {}) {
    console.log('🔍 Applying filters:', JSON.stringify(filters, null, 2));
    
    if (!filters || Object.keys(filters).length === 0) {
        console.log('✅ No filters applied, returning all leads');
        return leads;
    }

    let filteredLeads = [...leads];

    // Apply minimum rating filter
    if (filters.minRating !== null && filters.minRating !== undefined) {
        filteredLeads = filterByRating(filteredLeads, filters.minRating);
    }

    // Apply website filters
    if (filters.noWebsite === true) {
        filteredLeads = filterByNoWebsite(filteredLeads);
    } else if (filters.hasWebsite === true) {
        filteredLeads = filterByHasWebsite(filteredLeads);
    }

    console.log(`✅ Filtered ${leads.length} leads to ${filteredLeads.length} leads`);
    
    return filteredLeads;
}

/**
 * Filter leads by minimum rating
 * @param {Array} leads - Array of lead objects
 * @param {number} minRating - Minimum rating threshold
 * @returns {Array} - Filtered leads
 */
function filterByRating(leads, minRating) {
    const threshold = parseFloat(minRating);
    
    if (isNaN(threshold)) {
        console.log(`⚠️  Invalid rating threshold: ${minRating}`);
        return leads;
    }

    console.log(`🔍 Filtering by rating >= ${threshold}`);
    
    return leads.filter(lead => {
        const rating = parseFloat(lead.rating);
        return !isNaN(rating) && rating >= threshold;
    });
}

/**
 * Filter leads that have no website
 * @param {Array} leads - Array of lead objects
 * @returns {Array} - Filtered leads
 */
function filterByNoWebsite(leads) {
    console.log('🔍 Filtering for leads WITHOUT websites');
    
    return leads.filter(lead => {
        // Check if website field is empty, null, or undefined
        const hasNoWebsite = !lead.website || 
                            lead.website.trim() === '' || 
                            lead.hasWebsite === false;
        return hasNoWebsite;
    });
}

/**
 * Filter leads that have a website
 * @param {Array} leads - Array of lead objects
 * @returns {Array} - Filtered leads
 */
function filterByHasWebsite(leads) {
    console.log('🔍 Filtering for leads WITH websites');
    
    return leads.filter(lead => {
        // Check if website field has a value
        const hasWebsite = lead.website && 
                          lead.website.trim() !== '' && 
                          lead.hasWebsite !== false;
        return hasWebsite;
    });
}

/**
 * Filter leads by review count
 * @param {Array} leads - Array of lead objects
 * @param {number} minReviews - Minimum review count
 * @returns {Array} - Filtered leads
 */
function filterByMinReviews(leads, minReviews) {
    const threshold = parseInt(minReviews, 10);
    
    if (isNaN(threshold)) {
        console.log(`⚠️  Invalid review threshold: ${minReviews}`);
        return leads;
    }

    console.log(`🔍 Filtering by review count >= ${threshold}`);
    
    return leads.filter(lead => {
        const reviewCount = parseInt(lead.reviewCount, 10);
        return !isNaN(reviewCount) && reviewCount >= threshold;
    });
}

/**
 * Filter leads by category
 * @param {Array} leads - Array of lead objects
 * @param {string} category - Category to filter by
 * @returns {Array} - Filtered leads
 */
function filterByCategory(leads, category) {
    if (!category || typeof category !== 'string') {
        return leads;
    }

    const normalizedCategory = category.toLowerCase().trim();
    console.log(`🔍 Filtering by category: ${normalizedCategory}`);
    
    return leads.filter(lead => {
        const leadCategory = (lead.category || '').toLowerCase().trim();
        return leadCategory.includes(normalizedCategory) || 
               normalizedCategory.includes(leadCategory);
    });
}

/**
 * Filter leads by location
 * @param {Array} leads - Array of lead objects
 * @param {string} location - Location to filter by
 * @returns {Array} - Filtered leads
 */
function filterByLocation(leads, location) {
    if (!location || typeof location !== 'string') {
        return leads;
    }

    const normalizedLocation = location.toLowerCase().trim();
    console.log(`🔍 Filtering by location: ${normalizedLocation}`);
    
    return leads.filter(lead => {
        const leadLocation = (lead.location || '').toLowerCase().trim();
        const leadAddress = (lead.address || '').toLowerCase().trim();
        return leadLocation.includes(normalizedLocation) || 
               leadAddress.includes(normalizedLocation);
    });
}

/**
 * Filter leads by phone availability
 * @param {Array} leads - Array of lead objects
 * @param {boolean} hasPhone - Whether lead should have phone
 * @returns {Array} - Filtered leads
 */
function filterByPhone(leads, hasPhone = true) {
    console.log(`🔍 Filtering for leads ${hasPhone ? 'WITH' : 'WITHOUT'} phone numbers`);
    
    return leads.filter(lead => {
        const hasPhoneNumber = lead.phone && lead.phone.trim() !== '';
        return hasPhone ? hasPhoneNumber : !hasPhoneNumber;
    });
}

/**
 * Filter leads by email availability
 * @param {Array} leads - Array of lead objects
 * @param {boolean} hasEmail - Whether lead should have email
 * @returns {Array} - Filtered leads
 */
function filterByEmail(leads, hasEmail = true) {
    console.log(`🔍 Filtering for leads ${hasEmail ? 'WITH' : 'WITHOUT'} email addresses`);
    
    return leads.filter(lead => {
        const hasEmailAddress = lead.email && lead.email.trim() !== '';
        return hasEmail ? hasEmailAddress : !hasEmailAddress;
    });
}

/**
 * Sort leads by rating (descending)
 * @param {Array} leads - Array of lead objects
 * @returns {Array} - Sorted leads
 */
function sortByRating(leads) {
    return [...leads].sort((a, b) => {
        const ratingA = parseFloat(a.rating) || 0;
        const ratingB = parseFloat(b.rating) || 0;
        return ratingB - ratingA;
    });
}

/**
 * Sort leads by review count (descending)
 * @param {Array} leads - Array of lead objects
 * @returns {Array} - Sorted leads
 */
function sortByReviewCount(leads) {
    return [...leads].sort((a, b) => {
        const reviewsA = parseInt(a.reviewCount, 10) || 0;
        const reviewsB = parseInt(b.reviewCount, 10) || 0;
        return reviewsB - reviewsA;
    });
}

/**
 * Get filter statistics
 * @param {Array} originalLeads - Original leads array
 * @param {Array} filteredLeads - Filtered leads array
 * @param {Object} filters - Applied filters
 * @returns {Object} - Statistics object
 */
function getFilterStats(originalLeads, filteredLeads, filters) {
    const stats = {
        originalCount: originalLeads.length,
        filteredCount: filteredLeads.length,
        removedCount: originalLeads.length - filteredLeads.length,
        removalPercentage: originalLeads.length > 0 
            ? ((originalLeads.length - filteredLeads.length) / originalLeads.length * 100).toFixed(1)
            : 0,
        appliedFilters: Object.keys(filters).filter(key => {
            const value = filters[key];
            return value !== null && value !== undefined && value !== false;
        })
    };

    return stats;
}

// ============================================
// Export
// ============================================

module.exports = {
    applyFilters,
    filterByRating,
    filterByNoWebsite,
    filterByHasWebsite,
    filterByMinReviews,
    filterByCategory,
    filterByLocation,
    filterByPhone,
    filterByEmail,
    sortByRating,
    sortByReviewCount,
    getFilterStats
};
